SEVERNI POPEL — Android/PC Godot game project

This is an original, stylized third-person action-adventure project inspired by Norse mythology and the over-the-shoulder action-adventure genre. It is NOT an official God of War product and contains no Sony/PlayStation game assets.

PROJECT STATUS
- Playable 3D campaign foundation with three chapters and three character combat styles.
- Procedurally generated snowy forest arena, stones and gate.
- Third-person camera, movement, enemy pursuit/attacks, melee combat, dodge, health, boss enemy, chapter progression and Czech UI.
- Touch joystick, touch camera drag, attack/dodge/character buttons.
- Keyboard controls for desktop testing.
- All visuals are primitive procedural models. This is an early playable build, not a finished AAA-length game. Character models, animations, voice acting, cinematic cutscenes, save slots, detailed levels and final Android optimization remain future work.

OPENING THE PROJECT
1. Install Godot 4.3 or newer (standard edition).
2. Extract the ZIP.
3. In Godot Project Manager choose Import and select project.godot.
4. Press F6/F5 to run.

CONTROLS
PC: WASD move, mouse look, SPACE attack, SHIFT dodge, Q switch appearance, ESC release mouse.
Mobile: left virtual joystick move, drag right side to look, on-screen buttons attack/dodge/switch character.

ANDROID APK EXPORT
Godot Editor > Editor > Manage Export Templates: install matching templates.
Install Android build template / Android SDK + JDK as described in the official Godot documentation, then Project > Export > Add Android. Export a debug APK for testing. This environment did not contain Godot, Android SDK or export templates, so an APK could not be built or tested here.
