extends Node3D

# Severni popel - stylized third-person action adventure prototype/campaign.
# All visuals are original procedural primitives; no copyrighted game assets.

const CHAPTERS := [
	{"name":"KAPITOLA I — POPel V LESE", "hero":"KRATOS", "goal":4, "intro":"Kratos a Atreus opousteji les. Ve snehu se objevuji stopy, ktere tam nepatri.", "next":"Cesta je zablokovana. Zlikviduj severske prizraky."},
	{"name":"KAPITOLA II — SYN LUKU", "hero":"ATREUS", "goal":5, "intro":"Atreus zaslechne volani z rozvalin. Kratos mu kryje zada, ale tentokrat musi chlapec jednat sam.", "next":"Atreus musi probojovat cestu k runovemu kameni."},
	{"name":"KAPITOLA III — ZA OPONOU", "hero":"FAYE", "goal":6, "intro":"Daleko od Midgardu se Faye probouzi v cizi krajine. Jeji cesta se propleta s osudem rodiny.", "next":"Faye hleda pruchod z mlzneho udoli. Poraz strazce brany."}
]

var player: CharacterBody3D
var camera: Camera3D
var enemies: Array[CharacterBody3D] = []
var chapter := 0
var defeated := 0
var health := 100.0
var attack_cooldown := 0.0
var dodge_timer := 0.0
var joystick := Vector2.ZERO
var look_drag := Vector2.ZERO
var yaw := 0.0
var pitch := -0.18
var cam_distance := 6.0
var game_over := false
var completed := false
var hud: CanvasLayer
var title_label: Label
var objective_label: Label
var story_label: Label
var health_label: Label
var progress_label: Label
var joy_base: Control
var joy_knob: ColorRect
var attack_button: Button
var dodge_button: Button
var switch_button: Button
var world_root: Node3D
var hero_mesh: MeshInstance3D
var hero_materials := [Color(0.28,0.34,0.39), Color(0.18,0.34,0.52), Color(0.52,0.43,0.28)]

func _ready() -> void:
	_build_world()
	_build_player()
	_build_camera()
	_build_hud()
	_start_chapter(0)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.10,0.16,0.22)
	sky_mat.sky_horizon_color = Color(0.42,0.48,0.50)
	sky_mat.ground_bottom_color = Color(0.08,0.10,0.11)
	sky_mat.ground_horizon_color = Color(0.28,0.31,0.31)
	environment.sky.sky_material = sky_mat
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.52,0.59,0.68)
	environment.ambient_light_energy = 0.65
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.environment = environment
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48,-32,0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)
	world_root = Node3D.new()
	world_root.name = "World"
	add_child(world_root)
	var ground := StaticBody3D.new()
	ground.name = "Ground"
	var mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(90,90)
	mesh.mesh = plane
	mesh.material_override = _mat(Color(0.31,0.35,0.34), 0.95)
	ground.add_child(mesh)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(90,0.4,90)
	col.shape = shape
	col.position.y = -0.22
	ground.add_child(col)
	world_root.add_child(ground)
	# Frosted pines and broken standing stones form a simple explorable arena.
	for i in range(46):
		var angle := float(i) * 2.399
		var radius := 11.0 + float((i * 17) % 23)
		var x := cos(angle) * radius
		var z := sin(angle) * radius
		if Vector2(x,z).length() < 8.0: continue
		_add_tree(Vector3(x,0,z), 0.75 + float(i%4)*0.15)
	for i in range(10):
		var a := float(i) * TAU / 10.0
		_add_stone(Vector3(cos(a)*7.5,0,sin(a)*7.5), 0.7 + float(i%3)*0.25)
	# A distant gate gives the player a visible destination.
	_add_gate(Vector3(0,0,-27))

func _add_tree(pos: Vector3, scale_value: float) -> void:
	var tree := Node3D.new()
	tree.position = pos
	tree.scale = Vector3.ONE * scale_value
	var trunk := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.22
	cylinder.bottom_radius = 0.34
	cylinder.height = 3.2
	trunk.mesh = cylinder
	trunk.position.y = 1.6
	trunk.material_override = _mat(Color(0.20,0.17,0.14))
	tree.add_child(trunk)
	for j in range(3):
		var crown := MeshInstance3D.new()
		var cone := ConeMesh.new()
		cone.bottom_radius = 1.25 - j*0.22
		cone.height = 2.0
		crown.mesh = cone
		crown.position.y = 2.3 + j*0.95
		crown.material_override = _mat(Color(0.20,0.30,0.31) if j != 0 else Color(0.30,0.38,0.38))
		tree.add_child(crown)
	world_root.add_child(tree)

func _add_stone(pos: Vector3, size_value: float) -> void:
	var stone := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.7,2.6,0.65) * size_value
	stone.mesh = box
	stone.position = pos + Vector3(0,1.3*size_value,0)
	stone.rotation.y = size_value
	stone.material_override = _mat(Color(0.37,0.42,0.44))
	world_root.add_child(stone)

func _add_gate(pos: Vector3) -> void:
	for side in [-1,1]:
		var pillar := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(1.2,5.8,1.2)
		pillar.mesh = box
		pillar.position = pos + Vector3(float(side)*3.0,2.9,0)
		pillar.material_override = _mat(Color(0.34,0.39,0.42))
		world_root.add_child(pillar)
	var beam := MeshInstance3D.new()
	var beam_mesh := BoxMesh.new()
	beam_mesh.size = Vector3(7.2,0.8,1.3)
	beam.mesh = beam_mesh
	beam.position = pos + Vector3(0,5.6,0)
	beam.material_override = _mat(Color(0.40,0.44,0.44))
	world_root.add_child(beam)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Hero"
	player.position = Vector3(0,0.15,8)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.48
	capsule.height = 1.9
	collision.shape = capsule
	collision.position.y = 0.95
	player.add_child(collision)
	hero_mesh = MeshInstance3D.new()
	var body := CapsuleMesh.new()
	body.radius = 0.48
	body.height = 1.9
	hero_mesh.mesh = body
	hero_mesh.position.y = 0.95
	hero_mesh.material_override = _mat(hero_materials[0])
	player.add_child(hero_mesh)
	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.31
	head_mesh.height = 0.62
	head.mesh = head_mesh
	head.position = Vector3(0,2.05,0)
	head.material_override = _mat(Color(0.72,0.57,0.45))
	player.add_child(head)
	var weapon := MeshInstance3D.new()
	var weapon_mesh := BoxMesh.new()
	weapon_mesh.size = Vector3(0.13,1.25,0.18)
	weapon.mesh = weapon_mesh
	weapon.position = Vector3(0.62,1.05,-0.05)
	weapon.rotation.z = -0.25
	weapon.material_override = _mat(Color(0.63,0.69,0.73),0.25)
	weapon.name = "Weapon"
	player.add_child(weapon)
	add_child(player)

func _build_camera() -> void:
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position = Vector3(0,1.55,0)
	player.add_child(pivot)
	camera = Camera3D.new()
	camera.current = true
	camera.position = Vector3(0,1.0,cam_distance)
	camera.rotation.x = -0.12
	camera.fov = 72
	pivot.add_child(camera)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var top := PanelContainer.new()
	top.position = Vector2(18,16)
	top.size = Vector2(510,116)
	top.add_theme_stylebox_override("panel", _panel_style(Color(0.025,0.04,0.055,0.82)))
	hud.add_child(top)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation",3)
	top.add_child(v)
	title_label = _label("SEVERNI POPEL",22,Color(0.91,0.83,0.66))
	v.add_child(title_label)
	objective_label = _label("Ukol",16,Color.WHITE)
	v.add_child(objective_label)
	progress_label = _label("Postup",14,Color(0.72,0.81,0.86))
	v.add_child(progress_label)
	health_label = _label("ZDRAVI 100",14,Color(0.85,0.42,0.35))
	v.add_child(health_label)
	story_label = _label("",17,Color(0.96,0.92,0.82))
	story_label.position = Vector2(260,150)
	story_label.size = Vector2(760,100)
	story_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hud.add_child(story_label)
	# Mobile joystick and action buttons.
	joy_base = Control.new()
	joy_base.position = Vector2(38,520)
	joy_base.size = Vector2(150,150)
	joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(joy_base)
	var base := ColorRect.new()
	base.color = Color(0.72,0.82,0.88,0.17)
	base.size = Vector2(140,140)
	base.position = Vector2(5,5)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	base.add_theme_stylebox_override("", _panel_style(Color(0.72,0.82,0.88,0.17)))
	joy_base.add_child(base)
	joy_knob = ColorRect.new()
	joy_knob.color = Color(0.88,0.91,0.93,0.48)
	joy_knob.size = Vector2(54,54)
	joy_knob.position = Vector2(48,48)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joy_base.add_child(joy_knob)
	attack_button = _make_button("UTOK", Vector2(1120,570), Vector2(120,88), Color(0.50,0.16,0.13))
	attack_button.pressed.connect(_attack)
	dodge_button = _make_button("ÚSKOK", Vector2(1000,625), Vector2(100,66), Color(0.16,0.30,0.40))
	dodge_button.pressed.connect(_dodge)
	switch_button = _make_button("POSTAVA", Vector2(1090,475), Vector2(150,58), Color(0.25,0.29,0.31))
	switch_button.pressed.connect(_switch_character)
	var help := _label("PC: WASD pohyb • myš kamera • SPACE útok • SHIFT úskok • Q postava",13,Color(0.78,0.82,0.84))
	help.position = Vector2(260,680)
	help.size = Vector2(750,26)
	hud.add_child(help)

func _label(txt: String, font_size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",color)
	return l

func _make_button(txt: String, pos: Vector2, size: Vector2, color: Color) -> Button:
	var b := Button.new()
	b.text = txt
	b.position = pos
	b.size = size
	b.add_theme_font_size_override("font_size",18)
	b.add_theme_color_override("font_color",Color.WHITE)
	b.add_theme_stylebox_override("normal",_panel_style(color))
	b.add_theme_stylebox_override("pressed",_panel_style(color.lightened(0.25)))
	hud.add_child(b)
	return b

func _panel_style(color: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.corner_radius_top_left = 12
	s.corner_radius_top_right = 12
	s.corner_radius_bottom_left = 12
	s.corner_radius_bottom_right = 12
	s.border_width_left = 1
	s.border_width_right = 1
	s.border_width_top = 1
	s.border_width_bottom = 1
	s.border_color = Color(0.75,0.79,0.80,0.25)
	return s

func _mat(color: Color, roughness: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	return m

func _start_chapter(index: int) -> void:
	chapter = index
	defeated = 0
	health = 100.0
	game_over = false
	completed = false
	player.global_position = Vector3(0,0.15,8)
	for e in enemies:
		if is_instance_valid(e): e.queue_free()
	enemies.clear()
	var data: Dictionary = CHAPTERS[chapter]
	_set_hero(data.hero)
	title_label.text = data.name
	objective_label.text = data.next
	story_label.text = data.intro
	story_label.visible = true
	var timer := get_tree().create_timer(5.5)
	timer.timeout.connect(_hide_story)
	for i in range(int(data.goal)):
		var a := float(i) * TAU / float(data.goal) + 0.35
		_spawn_enemy(Vector3(cos(a)* (11.0 + float(i%2)*2.0),0,sin(a)*(11.0 + float(i%2)*2.0)-9.0), i == int(data.goal)-1)
	_update_hud()

func _set_hero(hero: String) -> void:
	var idx := 0
	if hero == "ATREUS": idx = 1
	elif hero == "FAYE": idx = 2
	hero_mesh.material_override = _mat(hero_materials[idx])
	var weapon := player.get_node_or_null("Weapon") as MeshInstance3D
	if weapon:
		if idx == 1:
			weapon.scale = Vector3(0.7,0.75,0.7)
			weapon.material_override = _mat(Color(0.45,0.29,0.13))
		elif idx == 2:
			weapon.scale = Vector3(0.8,1.1,0.8)
			weapon.material_override = _mat(Color(0.78,0.72,0.52))
		else:
			weapon.scale = Vector3.ONE
			weapon.material_override = _mat(Color(0.63,0.69,0.73),0.25)

func _spawn_enemy(pos: Vector3, boss: bool) -> void:
	var e := CharacterBody3D.new()
	e.name = "Boss" if boss else "Draugr"
	e.position = pos
	e.set_meta("hp", 170.0 if boss else 65.0)
	e.set_meta("boss", boss)
	e.set_meta("attack_clock", 0.0)
	var c := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = 0.55 if boss else 0.42
	sh.height = 2.2 if boss else 1.7
	c.shape = sh
	c.position.y = 1.0
	e.add_child(c)
	var m := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.55 if boss else 0.42
	cap.height = 2.2 if boss else 1.7
	m.mesh = cap
	m.position.y = 1.0
	m.material_override = _mat(Color(0.32,0.12,0.10) if boss else Color(0.25,0.31,0.34))
	e.add_child(m)
	var eyes := MeshInstance3D.new()
	var eye_mesh := SphereMesh.new()
	eye_mesh.radius = 0.10 if boss else 0.065
	eye_mesh.height = eye_mesh.radius*2
	eyes.mesh = eye_mesh
	eyes.position = Vector3(0,1.65,-0.36)
	eyes.material_override = _mat(Color(1.0,0.28,0.08),0.25)
	e.add_child(eyes)
	world_root.add_child(e)
	enemies.append(e)

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clamp(pitch - event.relative.y * 0.002, -0.55, 0.22)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if Input.mouse_mode == Input.MOUSE_MODE_VISIBLE: Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE: Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		elif event.keycode == KEY_SPACE: _attack()
		elif event.keycode == KEY_SHIFT: _dodge()
		elif event.keycode == KEY_Q: _switch_character()
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.42:
				joy_base.set_meta("touch",event.index)
				_update_joystick(event.position)
			else:
				joy_base.set_meta("look_touch",event.index)
				joy_base.set_meta("last_look",event.position)
		else:
			if joy_base.has_meta("touch") and int(joy_base.get_meta("touch")) == event.index:
				joy_base.remove_meta("touch")
				joystick = Vector2.ZERO
				joy_knob.position = Vector2(48,48)
			if joy_base.has_meta("look_touch") and int(joy_base.get_meta("look_touch")) == event.index:
				joy_base.remove_meta("look_touch")
	elif event is InputEventScreenDrag:
		if joy_base.has_meta("touch") and int(joy_base.get_meta("touch")) == event.index:
			_update_joystick(event.position)
		elif joy_base.has_meta("look_touch") and int(joy_base.get_meta("look_touch")) == event.index:
			var last: Vector2 = joy_base.get_meta("last_look")
			var delta := event.position-last
			yaw -= delta.x*0.006
			pitch = clamp(pitch-delta.y*0.004,-0.55,0.22)
			joy_base.set_meta("last_look",event.position)

func _update_joystick(screen_pos: Vector2) -> void:
	var local := screen_pos - joy_base.global_position - Vector2(75,75)
	joystick = local.limit_length(58.0) / 58.0
	joy_knob.position = Vector2(48,48) + joystick*43.0

func _process(delta: float) -> void:
	if game_over or completed: return
	attack_cooldown = maxf(0.0,attack_cooldown-delta)
	dodge_timer = maxf(0.0,dodge_timer-delta)
	var input_dir := Vector2.ZERO
	input_dir.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_dir.y = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
	if joystick.length() > 0.08: input_dir = joystick
	input_dir = input_dir.limit_length(1.0)
	var basis := Basis(Vector3.UP,yaw)
	var move3 := basis * Vector3(input_dir.x,0,input_dir.y)
	var speed := 5.2 if chapter != 1 else 6.0
	if dodge_timer > 0: speed = 12.0
	player.velocity.x = move3.x*speed
	player.velocity.z = move3.z*speed
	player.velocity.y -= 22.0*delta
	player.move_and_slide()
	if move3.length() > 0.1:
		player.rotation.y = lerp_angle(player.rotation.y, atan2(-move3.x,-move3.z), delta*9.0)
	var pivot := player.get_node("CameraPivot") as Node3D
	pivot.rotation.y = yaw
	pivot.rotation.x = pitch
	camera.position = camera.position.lerp(Vector3(0,1.0,cam_distance),delta*5.0)
	for e in enemies.duplicate():
		if not is_instance_valid(e):
			enemies.erase(e)
			continue
		var to_player := player.global_position - e.global_position
		var dist := to_player.length()
		if dist > 1.7:
			var dir := to_player.normalized()
			e.velocity.x = dir.x * (2.1 if not bool(e.get_meta("boss")) else 1.6)
			e.velocity.z = dir.z * (2.1 if not bool(e.get_meta("boss")) else 1.6)
			e.rotation.y = atan2(-dir.x,-dir.z)
		else:
			e.velocity.x = 0
			e.velocity.z = 0
			var clock := float(e.get_meta("attack_clock")) - delta
			if clock <= 0:
				if dodge_timer <= 0:
					health -= 10.0 if not bool(e.get_meta("boss")) else 18.0
				clock = 1.55 if not bool(e.get_meta("boss")) else 1.2
				e.set_meta("attack_clock",clock)
		e.velocity.y -= 22.0*delta
		e.move_and_slide()
	if health <= 0:
		game_over = true
		story_label.text = "PADL JSI V BOJI\nStiskni OPAKOVAT a zkus to znovu."
		story_label.visible = true
		var retry := _make_button("OPAKOVAT",Vector2(535,390),Vector2(210,70),Color(0.42,0.16,0.13))
		retry.pressed.connect(_retry_chapter.bind(retry))
	_update_hud()

func _attack() -> void:
	if attack_cooldown > 0 or game_over or completed: return
	attack_cooldown = 0.52
	var damage := 48.0 if chapter == 0 else (34.0 if chapter == 1 else 42.0)
	var reach := 3.0
	var hit_any := false
	for e in enemies.duplicate():
		if is_instance_valid(e) and player.global_position.distance_to(e.global_position) < reach:
			var forward := -player.global_transform.basis.z
			var to_enemy := (e.global_position-player.global_position).normalized()
			if forward.dot(to_enemy) > -0.15:
				e.set_meta("hp",float(e.get_meta("hp"))-damage)
				e.position += to_enemy*0.7
				hit_any = true
				if float(e.get_meta("hp")) <= 0:
					enemies.erase(e)
					e.queue_free()
					defeated += 1
					if defeated >= int(CHAPTERS[chapter].goal): _chapter_complete()
	if hit_any: story_label.text = "ZASAH!"
	_update_hud()

func _dodge() -> void:
	if not game_over and not completed: dodge_timer = 0.28

func _switch_character() -> void:
	if game_over or completed: return
	var hero := String(CHAPTERS[chapter].hero)
	if hero == "KRATOS": _set_hero("ATREUS")
	elif hero == "ATREUS": _set_hero("KRATOS")
	else: _set_hero("FAYE")
	story_label.text = "ZMENIL JSI BOJOVY STYL"
	story_label.visible = true

func _chapter_complete() -> void:
	if chapter < CHAPTERS.size()-1:
		story_label.text = "KAPITOLA DOKONCENA\nPokracujes do dalsi casti pribehu..."
		story_label.visible = true
		var next := _make_button("DALSI KAPITOLA",Vector2(520,390),Vector2(240,70),Color(0.22,0.34,0.34))
		next.pressed.connect(_next_chapter.bind(next))
	else:
		completed = true
		story_label.text = "KONEC PRVNIHO DOBRODRUZSTVI\nSeverni popel — cesta teprve zacina.\nDekujeme za hrani!"
		story_label.visible = true
		var again := _make_button("HRAT ZNOVU",Vector2(535,405),Vector2(210,70),Color(0.22,0.34,0.34))
		again.pressed.connect(_restart_campaign.bind(again))

func _update_hud() -> void:
	if not is_instance_valid(health_label): return
	health_label.text = "ZDRAVI  %d / 100" % int(maxf(0,health))
	progress_label.text = "NEPRATELE  %d / %d" % [defeated,int(CHAPTERS[chapter].goal)]

func _hide_story() -> void:
	if is_instance_valid(story_label): story_label.visible = false

func _retry_chapter(button: Button) -> void:
	button.queue_free()
	_start_chapter(chapter)

func _next_chapter(button: Button) -> void:
	button.queue_free()
	_start_chapter(chapter + 1)

func _restart_campaign(button: Button) -> void:
	button.queue_free()
	_start_chapter(0)
